from gui.gui import TelemetryAppGUI

def main() -> None:
    app = TelemetryAppGUI()
    app.mainloop()

if __name__ == '__main__':
    main()