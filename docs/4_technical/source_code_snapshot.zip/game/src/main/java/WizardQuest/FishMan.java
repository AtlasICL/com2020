package WizardQuest;

import java.util.LinkedList;
import java.util.List;

/**
 * Fishman - is a water-based beginner-level enemy
 * Uses water based techniques, and is water damage resistant
 * Phase 1 enemy
 */
public class FishMan extends EnemyBase {
    /**
     *
     * @param difficulty defines the current game difficulty for this concrete enemy, used to scale health
     */
    public FishMan(DifficultyEnum difficulty){
        super((int) Math.round(50 * SettingsSingleton.getInstance().getEnemyMaxHealthMultiplier(difficulty)));
    }
    @Override
    public List<AbilityEnum> getAbilities(){
        LinkedList<AbilityEnum> abilities = new LinkedList<>();
        abilities.add(AbilityEnum.PUNCH);
        abilities.add(AbilityEnum.WATER_JET);
        return abilities;
    }
    @Override
    public EntityEnum getType(){
        return EntityEnum.FISH_MAN;
    }

    @Override
    public void loseHealth(int amount, DamageEnum type){
        if (type == DamageEnum.THUNDER){
            amount = (int) Math.round(amount * 2.0);
        }
        else if (type == DamageEnum.WATER){
            amount = (int) Math.round(amount / 2.0);
        }
        super.loseHealth(amount, type);
    }
}

